/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.viewcontrol;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 *
 * @author PCS
 */
public class Home_CL {
    @FXML
    private Button carR;

    @FXML
    private Button customer;

    @FXML
    private Button rental;

    @FXML
    private Button returncar;

    @FXML
    private Button logout;

    @FXML
    void openCarRegistration(ActionEvent e) throws IOException {
        Node node=(Node) e.getSource();
        Stage stage=(Stage) node.getScene().getWindow();
        Parent root;
        root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/CarRegistrationFXML.fxml"));
        Scene scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void openCustomer(ActionEvent e) throws IOException {
        Node node=(Node) e.getSource();
        Stage stage=(Stage) node.getScene().getWindow();
        Parent root;
        root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/CustomerFXML.fxml"));
        Scene scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void openRental(ActionEvent e) throws IOException {
        Node node=(Node) e.getSource();
        Stage stage=(Stage) node.getScene().getWindow();
        Parent root;
        root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/RentalFXML.fxml"));
        Scene scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
       
    public void Back(Event e) {
        try {
            Node node = (Node) e.getSource();
            Stage stage = (Stage) node.getScene().getWindow();                  
            stage.close();         
            Parent root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/loginFXML.fxml"));       
            Scene scene = new Scene(root);       
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            System.out.println("y"+ex.getMessage());
       }
    }       
}
