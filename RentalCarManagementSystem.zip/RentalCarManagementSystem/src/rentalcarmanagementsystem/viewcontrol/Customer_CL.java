/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.viewcontrol;

import rentalcarmanagementsystem.Controller.CustomerController;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import rentalcarmanagementsystem.model.CustomerModel;

/**
 *
 * @author PCS
 */
public class Customer_CL implements Initializable{
    @FXML
    private Label id1;

    @FXML
    private TextField txtid;

    @FXML
    private TextField txtname;

    @FXML
    private TextField txtaddress;
    
    @FXML
    private TextField txtphone;
    
    @FXML
    private TextField txtsearch;

    @FXML
    private TableView table;

    @FXML
    private TableColumn id;

    @FXML
    private TableColumn Name;

    @FXML
    private TableColumn Address;

    @FXML
    private TableColumn Phone;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnEdit;
      @FXML
    private Button btnback;
   
    CustomerController pc = new CustomerController();
    int ID;
    
    public void Add(Event e) {
        CustomerModel cust = new CustomerModel();
        cust.setId(Integer.parseInt( txtid.getText()));
        cust.setName(txtname.getText());
        cust.setAddress(txtaddress.getText());
        cust.setPhone(Integer.parseInt( txtphone.getText()));
        pc.insert(cust);
        table.setItems(pc.getAllCustomer());        
        txtid.setText("");
        txtname.setText("");
        txtaddress.setText("");
        txtphone.setText("");     
    }
       
    public void Update(Event e) {
        CustomerModel client = new CustomerModel();     
        client.setId(Integer.parseInt( txtid.getText()));
        client.setName(txtname.getText());
        client.setAddress(txtaddress.getText());
        client.setPhone(Integer.parseInt(txtphone.getText()));            
        pc.update(client);
        table.setItems(pc.getAllCustomer());
        txtid.setText("");
        txtname.setText("");
        txtaddress.setText("");
        txtphone.setText("");        
    }         
            
    public void Delete(Event e) {
        pc.delete(ID);  
        txtid.setText("");
        txtname.setText("");
        txtaddress.setText(""); 
        txtphone.setText("");         
        table.setItems(pc.getAllCustomer());        
    }
    
    public void clickTable(Event e) {
        CustomerModel cust =  (CustomerModel) table.getSelectionModel().getSelectedItem();
        txtid.setText(cust.getId()+"");
        txtname.setText(cust.getName()+"");
        txtaddress.setText(cust.getAddress()+"");
        txtphone.setText(cust.getPhone()+"");
        ID=cust.getId();        
    }
       
    public void Back(Event e) {
        try {
            Node node = (Node) e.getSource();
            Stage stage = (Stage) node.getScene().getWindow();                  
            stage.close();               
            Parent root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/HomeFXML.fxml"));       
            Scene scene = new Scene(root);       
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            System.out.println("y"+ex.getMessage());           
        }
    }
       
    public void Search(Event e) {          
        table.setItems(pc.getSearchCustomer(txtsearch.getText()));         
    }
       
    @Override
    public void initialize(URL location, ResourceBundle resources) {        
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        Name.setCellValueFactory(new PropertyValueFactory<>("Name"));
        Address.setCellValueFactory(new PropertyValueFactory<>("Address"));
        Phone.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        table.setItems(pc.getAllCustomer());     
    }     
}
