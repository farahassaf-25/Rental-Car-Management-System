/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.viewcontrol;

import static rentalcarmanagementsystem.Controller.CarController.IDS_Value_as_ArrayList;
import static rentalcarmanagementsystem.Controller.CustomerController.IDSCustomer_Value_as_ArrayList;
import rentalcarmanagementsystem.Controller.RentalController;
import java.net.URL;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import rentalcarmanagementsystem.model.RentalModel;

/**
 *
 * @author PCS
 */
public class Rental_CL implements Initializable {
    @FXML
    private TextField txtsearch;
    @FXML
    private TableColumn<RentalModel, Date> rentdate;
    @FXML
    private DatePicker txtrentdate;
    @FXML
    private DatePicker txtreturndate;
    @FXML
    private ComboBox<Integer> txtcustid;
    @FXML
    private TableColumn<RentalModel, Integer> carid;
    @FXML
    private Button txtedit;
    @FXML
    private Button txtadd;
    @FXML
    private Button txtdelete;
    @FXML
    private TableColumn<RentalModel, String> price;
    @FXML
    private TableColumn<RentalModel, Integer> custid;
    @FXML
    private TableColumn<RentalModel, Date> returndate;
    @FXML
    private ComboBox<Integer> txtcarid;
    @FXML
    private TextField txtprice;
    @FXML
    private TableView<RentalModel> table;
    @FXML
    private Button txtback;

    RentalController rc = new RentalController();
    int ID;

    public void Add(Event e) {
        RentalModel rm = new RentalModel();
        rm.setCarId(txtcarid.getValue());
        rm.setCustId(txtcustid.getValue());
        rm.setRentdate(Date.valueOf(txtrentdate.getValue()));
        rm.setReturndate(Date.valueOf(txtreturndate.getValue()));
        rm.setprice(Double.valueOf(txtprice.getText()));
        //System.out.println(rm.getprice());
        table.getItems().add(rm);
        rc.insert(rm);
    }

    public void Edit(Event e) {
        RentalModel rm = table.getSelectionModel().getSelectedItem();
        rm.setCarId(txtcarid.getValue());
        rm.setCustId(txtcustid.getValue());
        rm.setRentdate(Date.valueOf(txtrentdate.getValue()));
        rm.setReturndate(Date.valueOf(txtreturndate.getValue()));
        rm.setprice(Double.valueOf(txtprice.getText()));        
        rc.update(rm);      
        table.setItems(rc.getAll()); 
        txtcarid.getSelectionModel().clearSelection();
        txtcustid.getSelectionModel().clearSelection();
        txtrentdate.setValue(null);
        txtreturndate.setValue(null); 
        txtprice.setText("");
    }

    public void Delete(Event e) {
        RentalModel rm = table.getSelectionModel().getSelectedItem();
        table.getItems().remove(rm);
        rc.delete(rm.getCarId());
        table.setItems(rc.getAll());     
        txtprice.setText("");
        txtcustid.getSelectionModel().clearSelection();
        txtcarid.getSelectionModel().clearSelection();
        txtrentdate.setValue(null);
        txtreturndate.setValue(null); 
    }

    public void Back(Event e) {
        try {
            Node node = (Node) e.getSource();
            Stage stage = (Stage) node.getScene().getWindow();
            stage.close();
            Parent root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/HomeFXML.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
           // System.out.println("y" + ex.getMessage());
            ex.printStackTrace();
        }
    }
    

    public LocalDate dateToLocalDate(java.util.Date d) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        Instant instant = d.toInstant();
        LocalDate localDate = instant.atZone(defaultZoneId).toLocalDate();
        return localDate;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        for (int i = 0; i <= IDS_Value_as_ArrayList().size() - 1; i++) {
            txtcarid.getItems().add(IDS_Value_as_ArrayList().get(i));
        }
        for (int i = 0; i <= IDSCustomer_Value_as_ArrayList().size() - 1; i++) {
            txtcustid.getItems().add(IDSCustomer_Value_as_ArrayList().get(i));
        }

        carid.setCellValueFactory(new PropertyValueFactory<>("carId"));
        custid.setCellValueFactory(new PropertyValueFactory<>("custId"));
        rentdate.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().getRentdate()));
        returndate.setCellValueFactory(data -> new SimpleObjectProperty(data.getValue().getReturndate()));
        price.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().getprice())));

        table.setItems(rc.getAll());

        table.setRowFactory(tv -> {
                    TableRow<RentalModel> r = new TableRow<>();
                    r.setOnMouseClicked(event -> {
                        RentalModel rent = r.getItem();
                        txtcarid.setValue(rent.getCarId());
                        txtcustid.setValue(rent.getCustId());
                        txtrentdate.setValue(rent.getRentdate().toLocalDate());
                        txtreturndate.setValue(rent.getReturndate().toLocalDate());
                        txtprice.setText(String.valueOf(rent.getprice()));
                    });
                    return r;
                });
    }
}
