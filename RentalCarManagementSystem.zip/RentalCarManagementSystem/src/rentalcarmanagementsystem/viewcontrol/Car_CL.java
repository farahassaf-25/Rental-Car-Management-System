/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.viewcontrol;

import rentalcarmanagementsystem.Controller.CarController;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import rentalcarmanagementsystem.model.CarModel;

/**
 *
 * @author PCS
 */
public class Car_CL implements Initializable {
    @FXML
    private Label id1;
    @FXML
    private TextField txtid;
    @FXML
    private TextField txtname;
    @FXML
    private TextField txtavailable;   
    @FXML
    private TextField txtsearch;
    @FXML
    private TableView table;
    @FXML
    private TableColumn id;
    @FXML
    private TableColumn Name;
    @FXML
    private TableColumn Available;
    @FXML
    private Button btnDelete;
    @FXML
    private Button btnAdd;
    @FXML
    private Button btnEdit;   
    @FXML
    private Button btnBack;
    
    CarController pc = new CarController();
    int ID;
    
    public void Add(Event e) {
        CarModel car1 = new CarModel();
        car1.setId(Integer.parseInt( txtid.getText()));
        car1.setName(txtname.getText());
        car1.setAvailable(txtavailable.getText());
        pc.insert(car1);
        table.setItems(pc.getAllCar());       
        txtid.setText("");
        txtname.setText("");
        txtavailable.setText("");          
    }
        
    public void Update(Event e) {
        CarModel car = new CarModel();
        car.setId(Integer.parseInt(txtid.getText()));
        car.setName(txtname.getText());
        car.setAvailable(txtavailable.getText());
        pc.update(car);
        table.setItems(pc.getAllCar());
        txtid.setText("");
        txtname.setText("");
        txtavailable.setText("");         
    }         
              
    public void Delete(Event e) {
        pc.delete(ID);  
        txtid.setText("");
        txtname.setText("");
        txtavailable.setText(""); 
        table.setItems(pc.getAllCar());               
    }
       
    public void Back(Event e) {
        try {
            Node node = (Node) e.getSource();
            Stage stage = (Stage) node.getScene().getWindow();                  
            stage.close();                   
            Parent root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/HomeFXML.fxml"));       
            Scene scene = new Scene(root);       
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            System.out.println("y"+ex.getMessage());
        }
    }
 
    public void Search(Event e) {          
        table.setItems(pc.getSearchCar(txtsearch.getText()));         
    }
       
    public void clickTable(Event e) {
        CarModel car =  (CarModel) table.getSelectionModel().getSelectedItem();
        txtid.setText(car.getId()+"");
        txtname.setText(car.getName()+"");
        txtavailable.setText(car.getAvailable()+"");        
        ID=car.getId();  
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {        
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        Name.setCellValueFactory(new PropertyValueFactory<>("Name"));
        Available.setCellValueFactory(new PropertyValueFactory<>("Available"));
        table.setItems(pc.getAllCar());
    }        
}
