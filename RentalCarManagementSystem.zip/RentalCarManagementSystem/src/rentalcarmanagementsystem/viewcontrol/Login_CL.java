/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.viewcontrol;

import rentalcarmanagementsystem.Controller.LoginController;
import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import rentalcarmanagementsystem.model.Admin;

/**
 *
 * @author PCS
 */
public class Login_CL {
    @FXML
    private TextField txtuser;

    @FXML
    private PasswordField txtpass;

    @FXML
    private Button btnSignin;

    @FXML
    private Label lblMSG;
     @FXML
    private Button sup;

    Admin ad=new Admin();
    LoginController lg=new LoginController();
      
    public void isSign(Event e) throws SQLException, IOException{
        ad.setUsername(txtuser.getText());
        ad.setPassword(txtpass.getText());
        if(lg.isLogin(ad)){
            Node node=(Node) e.getSource();
            Stage stage=(Stage) node.getScene().getWindow();
            Parent root;
            root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/HomeFXML.fxml"));
        Scene scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
        else lblMSG.setText("username or password is wrong");
    }
    
    @FXML
    void openSignup(ActionEvent e) throws IOException {
        Node node=(Node) e.getSource();
        Stage stage=(Stage) node.getScene().getWindow();
        Parent root;
        root = FXMLLoader.load(getClass().getResource("/rentalcarmanagementsystem/view/SignupFXML.fxml"));
        Scene scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }   
}
