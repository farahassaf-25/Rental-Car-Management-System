/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.Controller;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import rentalcarmanagementsystem.model.RentalModel;

/**
 *
 * @author PCS
 */
public class RentalController {
    private Statement state ;
   
    public void delete(int id) {
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate("DELETE FROM `rental` WHERE carId ="+id);
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(RentalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insert(RentalModel rent) {
          try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate( "INSERT INTO `rental` (`carId`,`custId`,`Rent Date`, `Return Date`, `Price`) VALUES('"+rent.getCarId()+"','"+rent.getCustId()+"','"+rent.getRentdate()+"','"+rent.getReturndate()+"','"+rent.getprice()+"')");
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(RentalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  
    public void update(RentalModel rent) {
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate( "update `rental` set `carId`='"+rent.getCarId()+"', `custId`='"+rent.getCustId()+"',`Rent Date`='"+rent.getRentdate()+"', `Return Date`='"+rent.getReturndate()+"', `Price`='"+rent.getprice()+"' ");            
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(RentalController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }
    }
    
    public ObservableList<RentalModel> getAll() {
        ObservableList<RentalModel> rent =FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM rental");
            while(result.next()) {
                RentalModel obj = new RentalModel();   
                obj.setCarId(result.getInt(1));
                obj.setCustId(result.getInt(2));
                obj.setRentdate(result.getDate(3));
                obj.setReturndate(result.getDate(4));
                obj.setprice(result.getInt(5));
                rent.add(obj);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(RentalController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }    
        return rent;
    }
    
    public ObservableList<RentalModel> getSearch(int id) {
        ObservableList<RentalModel> rent =FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM rental WHERE carId LIKE '%"+id+"%'");                     
            while(result.next()) {
                RentalModel rm = new RentalModel();   
                rm.setCarId(result.getInt(1));
                rm.setCustId(result.getInt(2));
                rm.setRentdate(result.getDate(3));
                rm.setReturndate(result.getDate(4));
                rm.setprice(result.getInt(5));
                rent.add(rm);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(RentalController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }    
        return rent;
   }
    
    private ComboBox<Integer> carid;
    private ComboBox<Integer> custid;
    private Date rentDate;
    private Date returnDate;
    private int price;
    
    public Statement getState() {
        return state;
    }
    public void setState(Statement state) {
        this.state = state;
    }
    public ComboBox getCarId() {
        return carid;
    }
    public void setCarId(ComboBox carid) {
        this.carid = carid;
    }
    public ComboBox getCustId() {
        return custid;
    }
    public void setCustId(ComboBox custid) {
        this.custid = custid;
    }
    public Date getRentdate() {
        return rentDate;
    }
    public void setRentdate(Date rentDate) {
        this.rentDate = rentDate;
    }
     public Date getReturndate() {
        return returnDate;
    }
    public void setReturndate(Date returnDate) {
        this.returnDate = returnDate;
    }
    public int getprice() {
        return price;
    }
    public void setprice(int price) {
        this.price = price;
    }
}
