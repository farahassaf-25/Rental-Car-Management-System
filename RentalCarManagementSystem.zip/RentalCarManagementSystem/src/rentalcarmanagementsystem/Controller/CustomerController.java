/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.Controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import rentalcarmanagementsystem.model.CustomerModel;

/**
 *
 * @author PCS
 */
public class CustomerController {
    private Statement state ;
    
    public void delete(int id) {
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate("Delete FROM `customer` WHERE id = " + id);
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void insert(CustomerModel customer) {
        try {
            state = ConnectionDB.openConnection().createStatement();         
            state.executeUpdate( "INSERT INTO `customer` (`ID`, `Name`, `Address`, `Phone`) VALUES ('"+customer.getId()+"', '"+customer.getName()+"', '"+customer.getAddress()+"', '"+customer.getPhone()+"');");
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(CustomerModel customer) {
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate( "update `customer` set `Name`='"+customer.getName()+"',`Address`='"+customer.getAddress()+"',`Phone`='"+customer.getPhone()+"' " + "where id =" +customer.getId());            
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }
    }
    
    public ObservableList<CustomerModel> getAllCustomer() {
        ObservableList<CustomerModel> cust=FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM customer");                      
            while(result.next()) {
                CustomerModel obj = new CustomerModel();   
                obj.setId(result.getInt(1));
                obj.setName(result.getString(2));
                obj.setAddress(result.getString(3));
                obj.setPhone(result.getInt(4));            
                cust.add(obj);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }    
       return cust;
    }
   
    public static ArrayList<Integer> IDSCustomer_Value_as_ArrayList() {
        ArrayList<Integer> array_of_IDS_Cust =new ArrayList();
        try {
            Statement stm = ConnectionDB.openConnection().createStatement();
            ResultSet result =  stm.executeQuery("SELECT * FROM customer");
            while(result.next())
            {
             array_of_IDS_Cust.add(result.getInt(1)); 
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }
     return array_of_IDS_Cust;      
    }
   
    public ObservableList<CustomerModel> getSearchCustomer(String name) {
        ObservableList<CustomerModel> cust =FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM customer WHERE Name LIKE '%"+name+"%'");                     
            while(result.next()) {
                CustomerModel cm = new CustomerModel();   
                cm.setId(result.getInt(1));
                cm.setName(result.getString(2));
                cm.setAddress(result.getString(3));
                cm.setPhone(result.getInt(4));
                cust.add(cm);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }   
       return cust;
    }

    private int id;
    private String name;
    private String address;
    private int phone;

    public Statement getState() {
        return state;
    }
    public void setState(Statement state) {
        this.state = state;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }   
    public int getPhone() {
        return phone;
    }
    public void setPhone(int phone) {
        this.phone = phone;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }    
}
