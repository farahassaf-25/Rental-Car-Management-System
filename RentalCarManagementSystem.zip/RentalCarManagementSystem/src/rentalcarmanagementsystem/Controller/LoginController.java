/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.Controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import rentalcarmanagementsystem.model.Admin;

/**
 *
 * @author PCS
 */
public class LoginController {
     @FXML
    private TextField txtuser;

    @FXML
    private PasswordField txtpass;

    @FXML
    private Button btnSignin;

    @FXML
    private Label lblMSG;
     @FXML
    private Button sup;
    Statement st;
    public   boolean isLogin(Admin ad) throws SQLException{
        st=ConnectionDB.openConnection().createStatement();
        ResultSet res=  st.executeQuery(" select * from admins where username='"+ad.getUsername()+"' and password='"+ad.getPassword()+"'");
        if(res.next()) return true;
        return false;
    }
}
