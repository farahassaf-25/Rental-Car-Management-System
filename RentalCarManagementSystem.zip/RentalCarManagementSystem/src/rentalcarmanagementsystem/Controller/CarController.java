/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.Controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import rentalcarmanagementsystem.model.CarModel;

/**
 *
 * @author PCS
 */
public class CarController {
    private Statement state ;
   
    public void delete(int id) {
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate("Delete FROM `car` WHERE id = " + id);
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void insert(CarModel car1) {
          try {
            state = ConnectionDB.openConnection().createStatement();
          state.executeUpdate( "INSERT INTO `car` (`id`,`Name`,`Available`) VALUES('"+car1.getId()+"','"+car1.getName()+"','"+car1.getAvailable()+"')");
           ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(CarModel car) {
        try {
            state = ConnectionDB.openConnection().createStatement();
             state.executeUpdate( "update `car` set `Name`='"+car.getName()+"',`Available`='"+car.getAvailable()+"' " + "where id =" +car.getId());
            
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }
    }
    
    public ObservableList<CarModel> getAllCar() {
        ObservableList<CarModel> carr=FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM car");
            while(result.next()) {
                CarModel obj = new CarModel();   
                obj.setId(result.getInt(1));
                obj.setName(result.getString(2));
                obj.setAvailable(result.getString(3));            
                carr.add(obj);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }    
        return carr;
    }

    public static ArrayList<Integer> IDS_Value_as_ArrayList() {
        ArrayList<Integer> array_of_IDS=new ArrayList();
        try {
            Statement stm = ConnectionDB.openConnection().createStatement();
            ResultSet result =  stm.executeQuery("SELECT * FROM car where Available='yes'");  
            while(result.next()) {
                array_of_IDS.add(result.getInt(1));  
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }
        return array_of_IDS;      
   }
   
    public ObservableList<CarModel> getSearchCar(String name) {
        ObservableList<CarModel> car =FXCollections.observableArrayList();
        try {
            state = ConnectionDB.openConnection().createStatement();
            ResultSet result =  state.executeQuery("SELECT * FROM car WHERE Available='yes'");                      
            while(result.next()) {
                CarModel cm = new CarModel();   
                cm.setId(result.getInt(1));
                cm.setName(result.getString(2));
                cm.setAvailable(result.getString(3));
                car.add(cm);            
            }
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
            ConnectionDB.closeConnection();
        }     
        return car;
    }
    
    private int id;
    private String name;
    private String available;
    public Statement getState() {
        return state;
    }
    public void setState(Statement state) {
        this.state = state;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAvailable() {
        return available;
    }
    public void setAvailable(String available) {
        this.available = available;
    }  
}
