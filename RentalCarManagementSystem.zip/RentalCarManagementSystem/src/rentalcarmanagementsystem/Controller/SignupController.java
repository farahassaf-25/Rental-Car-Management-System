/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.Controller;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import rentalcarmanagementsystem.model.Admin;

/**
 *
 * @author PCS
 */
public class SignupController {
    @FXML
    private ImageView progress;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    @FXML
    private Button signup;

    @FXML
    private Button login;
    
    public void insert(Admin ad) {
        Statement state;
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate( "INSERT INTO `admins` (`username`,`password`) VALUES ('"+ad.getUsername()+"','"+ad.getPassword()+"')");
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
