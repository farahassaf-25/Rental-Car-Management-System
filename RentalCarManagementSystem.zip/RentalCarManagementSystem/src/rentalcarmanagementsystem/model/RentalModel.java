/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.model;

import java.sql.Date;

/**
 *
 * @author PCS
 */
public class RentalModel {
    private int carId;
    private int custId;
    private Date rentDate;
    private Date returnDate;
    private double price;
    
    public int getCarId() {
        return carId;
    }

    public void setCarId(int carid) {
        this.carId = carid;
    }
    
    public int getCustId() {
        return custId;
    }
    
    public void setCustId(int custid) {
        this.custId = custid;
    }
    
    public Date getRentdate() {
        return rentDate;
    }
    
    public void setRentdate(Date rentdate) {
        this.rentDate = rentdate;
    }
    
    public Date getReturndate() {
        return returnDate;
    }
    
    public void setReturndate(Date returndate) {
        this.returnDate = returndate;
    }
    
    public double getprice() {
        return price;
    }
    
    public void setprice(double price) {
        this.price = price;
    }
}
