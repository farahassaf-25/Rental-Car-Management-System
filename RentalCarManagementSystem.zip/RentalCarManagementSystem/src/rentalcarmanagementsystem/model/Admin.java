/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentalcarmanagementsystem.model;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import rentalcarmanagementsystem.Controller.CarController;
import rentalcarmanagementsystem.Controller.ConnectionDB;

/**
 *
 * @author PCS
 */
public class Admin {
    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
     public void insert(Admin ad) {
        Statement state;
        try {
            state = ConnectionDB.openConnection().createStatement();
            state.executeUpdate( "INSERT INTO `admins` (`username`,`password`) VALUES ('"+ad.getUsername()+"','"+ad.getPassword()+"')");
            ConnectionDB.closeConnection();
        } catch (SQLException ex) {
            ConnectionDB.closeConnection();
            Logger.getLogger(CarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
